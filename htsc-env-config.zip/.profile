# ~/.profile: executed by Bourne-compatible login shells.

if [ "$BASH" ]; then
  if [ -f ~/.bashrc ]; then
    . ~/.bashrc
  fi
fi

mesg n 2> /dev/null || true

# Added by swiftly
. "/root/.local/share/swiftly/env.sh"
. "$HOME/.cargo/env"
export HT_APIKEY="ht_Xsm4QmTKCg36xyNxtdvzQiGZbqTJOhCyPxiYjqQ08"
